######################################################################
# string operations
# see http://www.tutorialspoint.com/python/python_strings.htm for more
######################################################################
str = "Hello, how are you?"
print("string = ", str)
print("length = ", len(str))
print("First letter:", str[0]) # index starts at 0
print()

# ranges of strings (and lists) can be specified through an operation
# known as 'splicing', where str[a:b] returns the characters starting 
# at index 'a' and up to but NOT including index 'b'. 
# Note that 'a' and 'b' are optional, as seen below
print("First three letters are: ", str[0:3])
print("First three letters are: ", str[:3]) # start at beg of string by default
print("Skip the first 3 letters: ", str[3:]) # go to end of string by default
print()

# you can use the form [a:b:i] to get letters from index 'a' through 
# (but not including) 'b', selecting every ith letter, with i = 1 by default)
print("Every other letter is: ", str[0::2])
print("Every other letter is: ", str[::2])
print()

# i can be negative (use i = -1 to reverse the string)
print("String in reverse is: ", str[len(str):0:-1])
# but since 'a' and 'b' are optional, we can use:
print("String in reverse is: ", str[::-1])
print()

# use negative values for 'a' and/or 'b' to specify offset from the
# last index
print("The last 4 characters in the string are: ", str[-4:])
print()


# all uppercase
print ("Uppercase string: ", str.upper())
# all lowercase
print ("Lowercase string: ", str.lower())

# note: the 'upper' and 'lower' methods do not change the original 
# string (they create a copy of the string in all upper or lower case)
# if you want to change the string, you need to assign it:
# str = str.upper()

# count number of 'e's in the string (case sensitive count)
numE = str.count('e')
print("Number of 'e's =", numE)

# find a substring
print ("Index of ' ': ", str.find(' ')) # index of first occurence if found
print ("Index of ABC : ", str.find("ABC")) # return -1 if not found

# does string contain a substring?
print("The string is: ", str)
print ("string contains \"how\":", "how" in str)
print ("string contains \"where\":", "where" in str)


######################################################################
# Exercise:
# Prompt the user to enter a DNA sequence, and count the number of
# T's, C's, G's, and A's in the sequence
######################################################################
