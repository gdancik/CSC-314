###############################################
# Getting input from the keyboard
###############################################

# use raw_input function. Because this always returns a string, make sure to
# convert if necessary
num = raw_input("Enter a number: ")
x = int(raw_input("Enter x: "))
y = int(raw_input("Enter y: "))


print "num is a: ", type(num)
print "x is a: ", type(x)
print "y is a: ", type(y)

print "You entered the following numbers: " + str(x) + " and " + str(y)
print
print


name = raw_input("Enter your name: ")
print "Thank you", name


           
