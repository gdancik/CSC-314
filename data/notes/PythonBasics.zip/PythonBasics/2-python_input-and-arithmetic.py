###############################################
# Getting input from the keyboard
###############################################

# Use the input function. Note that 'input' always returns a string
# If you want a number (e.g., an int or float), you will need
# to convert it

num = input("Enter a number: ")
print ("num is a: ", type(num))

# if we want to get an integer from the user
x = int(input("Enter x: "))

print ("x is a: ", type(x))

# pause until user wants to continue
name = input("Press enter to continue...")
print()


######################################################################
# arithmetic is straightforward in Python 3*
# (Note: for Python 2, you need to worry about integer division)
######################################################################

print("5 / 2 = ", 5/2)  # normal division
print("5 % 2 = ", 5%2)  # mod operator returns the remainder
print("5.0 // 2 = ", 5.0 // 2)  # integer (floor) division
print("3 squared = ", 3**2)
print()

# The shortcuts += or -= can be used:
x = 3
x+= 2 # same as x = x + 2)
print("x = ", x)
print()