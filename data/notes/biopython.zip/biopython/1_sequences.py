#########################################################
# Biopython is a set of Python tools for biological 
# computation 
# for download instructions and an excellent tutorial, 
# see: http://biopython.org/wiki/Main_Page

# Sequences have built in methods for transcription,
# finding the complement, and translation
#########################################################

from Bio.Seq import Seq        # for Seq objects
from Bio.Alphabet import IUPAC # for alphabet

## sequence with generic alphabet ##
my_seq = Seq("AGTACACTGGT")
print("sequence = ", my_seq)
print("alphabet = ", my_seq.alphabet)
print()

## DNA sequence ##
dna = Seq("ATGACACTGTAGGAA", IUPAC.unambiguous_dna)
print("sequence =", dna)
print("alphabet type =", dna.alphabet)
print("DNA nucleotides =", dna.alphabet.letters)
print()

# print DNA complement
print("complement =", dna.complement())
print()

# trascribe from DNA (sense strand) to RNA
rna = dna.transcribe()
print("dna =", dna)
print("rna =", rna)
print()

# translate from RNA to protein (will translate past any stop codons by default)
# dna.translate() also can be used to translate directly from DNA sense strand
protein1 = rna.translate()  
print("protein = ", protein1)

# translate until first stop codon
protein = rna.translate(to_stop = True)
print ("protein = ", protein)


