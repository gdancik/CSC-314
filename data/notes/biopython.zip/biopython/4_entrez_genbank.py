##########################################################################
# Entrez example -- searching and finding summaries of entries from the
# HomoloGene database. The Entrez module allows you to query NCBI's 
# Entrez database (which includes GenBank, GenPept, and others)
##########################################################################

from Bio import Entrez

# you must specify your e-mail when connecting NCBI/Entrez
Entrez.email = "email@domain" # change to your e-mail


###################################################################
# Search GenBank -- how many human HBB genes are there?
###################################################################

# Entrez.esearch returns search results (only the first
# retmax = 20 IDs are returned by default)
# http://biopython.org/DIST/docs/tutorial/Tutorial.html#htoc113
term = 'HBB [Gene Name] AND "homo sapiens"[Organism]'
handle = Entrez.esearch(db="nucleotide", term=term)
record = Entrez.read(handle)

print("Search for " + term)
print("Number of results = " + record['Count'])

ids = record['IdList']
print(ids)
print()


###################################################################
# Download GenBank entry summary -- retreive summary of top hit
#     Entrez.esummary is used to retreive summaries
#     Entrez.efetch would be used to retreive an entire sequence
#       record
###################################################################

id = ids[0]
print("Downloading sequence summary with GI " + id)
handle = Entrez.esummary(db="nucleotide", id = id, retmode='xml')
results = Entrez.parse(handle)
entry = next(results)
print("Accession:", entry['Caption'])
print("Length:", entry['Length'])
print("Title:", entry['Title'])


