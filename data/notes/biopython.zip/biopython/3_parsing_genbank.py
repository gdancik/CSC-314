#######################################################
# SeqIO.parse can be used to parse sequence data in
# GenBank flatfile format
#######################################################


from Bio import SeqIO # to parse sequence data
import urllib.request
import io # to convert string to 'handle'


# download 'file' from url and convert to file handle
url = "https://raw.githubusercontent.com/biopython/biopython/master/Doc/examples/ls_orchid.gbk"
handle = urllib.request.urlopen(url).read().decode('utf-8')
handle = io.StringIO(handle)


# parse sequences in 'genbank' format; this returns an iterator, which stores
# a sequence of elements
sequences = SeqIO.parse(handle, "genbank")

# seqence is an iterator, so we can use 'next' to get the next sequence 
# (in this case, the 'next' sequence is the first one)
seq_record = next(sequences)

# Each sequence is stored as a SeqRecord object
# http://biopython.org/DIST/docs/tutorial/Tutorial.html#htoc32
type(seq_record)

print("====================================")
print(seq_record)
print("====================================")
print()
print("ID = ", seq_record.id)
print("seq length = ", len(seq_record))
print() 
print(seq_record.seq)

print()

## look at the features 
print("features ---->")
print(seq_record.features)
print()

# look at first feature
f = seq_record.features[0]
print("type = ", f.type)
print("location = ", f.location)
print()

# we can get the 'start' and 'end' of a location, which
# corresponds to seq[start:end],
# i.e., start is starting index and end is end index + 1
start = f.location.start
end = f.location.end
print("sequence of first feature:", seq_record.seq[start:end])



