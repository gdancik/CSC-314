#######################################################
# SeqIO.parse can be used to parse sequence data in
# FASTA format
#######################################################

from Bio import SeqIO # to parse sequence data

import urllib.request
import io # to convert string to 'handle'

# download 'file' from url, and convert string to a file handle 
# (needed for SeqIO.parse) 

# normally read in a file the normal way
#handle = open("ls_orchid.fasta", "r")

# here we read in a file from a url, which must be converted
# to a file handle
url = "https://raw.githubusercontent.com/biopython/biopython/master/Doc/examples/ls_orchid.fasta"
handle = urllib.request.urlopen(url).read().decode('utf-8')
handle = io.StringIO(handle)


# parse sequences in 'fasta' format; this returns an iterator, 
# which stores a sequence of elements
sequences = SeqIO.parse(handle, "fasta")

# each sequence is stored as a SeqRecord object
# http://biopython.org/DIST/docs/tutorial/Tutorial.html#sec:seq_features

num = 1
# loop through up to first five sequence records in the file
for s in sequences:
    print("sequence #", num)
    print("====================================")    
    print()
    print( "ID = ", s.id)  # use .id for ID/header
    print(s.seq)	  # use .seq for sequence
    print("seq length = ", len(s))
    print()
    num = num + 1
    if num == 3 :
        break
