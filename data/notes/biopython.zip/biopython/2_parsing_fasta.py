#######################################################
# SeqIO.parse can be used to parse sequence data in
# FASTA format
#######################################################

from Bio import SeqIO # to parse sequence data

import urllib.request
import io # to convert string to 'handle'


# here we read in a file from a url, which must be converted
# to a file handle
url = "https://raw.githubusercontent.com/biopython/biopython/master/Doc/examples/ls_orchid.fasta"
handle = urllib.request.urlopen(url).read().decode('utf-8')
handle = io.StringIO(handle)

# parse (extract) sequence information using 'fasta' format; 
# this returns an iterator, 
# which stores a sequence of elements
sequences = SeqIO.parse(handle, "fasta")

################################################################
# Note #1: Normally you would read in a sequence directly from
# a file, and then parse it, using the following code
# with open("ls_orchid.fasta", "r") as handle:
#    sequences = SeqIO.parse(handle, "fasta")
################################################################

############################################################
# Note #2: an iterator is a a pointer to a sequence of 
# elements, that allows you to step through the sequence
# one element at a time. You cannot go backward. You can
#    - convert the iterator to a list, using list(iterator)
#    - get the next element, usign next(iterator)
#    - loop through the elements, as in the code below
############################################################

# each sequence is stored as a SeqRecord object
# http://biopython.org/DIST/docs/tutorial/Tutorial.html#sec:seq_features

num = 1
# loop through up to first three sequence records in the file
for s in sequences:
    print("sequence #", num)
    print("sequence length = ", len(s))
    print( "sequence ID = ", s.id)  # use .id for ID/header
    print(s.seq)	  # use .seq for sequence
    print()
    if num == 3 :
        break
    
    num = num + 1
