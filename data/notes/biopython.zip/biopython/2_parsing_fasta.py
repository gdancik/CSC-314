#######################################################
# SeqIO.parse can be used to parse sequence data in
# FASTA format
#######################################################

from Bio import SeqIO # to parse sequence data

import urllib2  # to read file from url
from StringIO import StringIO # to convert string to 'handle'

# download 'file' from url 
url = "https://raw.githubusercontent.com/biopython/biopython/master/Doc/examples/ls_orchid.fasta"
openUrl = urllib2.urlopen(url)
seqString = openUrl.read() # convert contents to string

# when using SeqIO, we need a handle to an open file
# here, we convert the sequences string to a handle 
handle = StringIO(seqString) 
print handle

# parse sequences in 'genbank' format; this returns an iterator, which stores
# a sequence of elements
sequences = SeqIO.parse(handle, "fasta")

# each sequence is stored as a SeqRecord object
# http://biopython.org/DIST/docs/tutorial/Tutorial.html#sec:seq_features

num = 1
# loop through up to first five sequence records in the file
for seq_record in sequences:
    print "sequence #", num 
    print "===================================="
    print seq_record
    print "===================================="
    print
    print "ID = ", seq_record.id  # use .id for ID/header
    print seq_record.seq	  # use .seq for sequence
    print "seq length = ", len(seq_record)
    print
    num = num + 1
    if num == 5 :
        break
    
