##########################################################################
# Entrez gene example -- a function that retreives Entrez Gene summaries
# for a specified gene, and prints out relevant information
#
# The Entrez Biopython module allows you to query NCBI's Entrez database
# (which includes GenBank, the Protein Dataase, and others
##########################################################################

from Bio import Entrez
Entrez.email = "specify e-mail address here"

## a function to return gene summaries based on the specified
## gene name search in humans
def getGeneSummary(gene) :
  term = gene + '[Gene Name] AND "Homo sapiens"[Organism]'
  handle = Entrez.esearch(db="gene", term=term)
  record = Entrez.read(handle)

  numResults = int(record['Count'])
  if numResults == 0 :
    return 'NO RESULTS'

  # multiple ids must be in list form
  idStr = ",".join(record['IdList'])
  handle = Entrez.esummary(db="gene", id=idStr)
  results = Entrez.read(handle)  
  results = results['DocumentSummarySet']
  results = results['DocumentSummary']
  for res in results :
    print ("Name:", res['Name'])
    print ("Description:", res['Description'])
    print ("Summary:", res['Summary'])

  return results


