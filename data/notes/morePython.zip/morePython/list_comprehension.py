###############################################################################
# list comprehension - allows for list construction in a 'natural' and concise
# way, following mathematical syntax:

# mathematical notation: {f(x) : x in values} 
#       python notation: [f(x) for x in values] 	  	    

# mathematical notation: {f(x) : x in values and condition is true} 
#       python notation: [f(x) for x in values if condition]     
###############################################################################


# output squared numbers for numbers 1 - 10
print "print i^2 for i = 1, 2, ....10"
for i in range(1,11):
  print i*i

print


# construct a list of squared numbers, for numbers 1 - 10
print "create list the old fashioned way"
squares = []
for i in range(1,11):
  squares.append(i*i)

# print list
print squares
print

# use list comprehension
print "list comprehension: " 
squares = [i*i for i in range(1,11)]
print squares
print

# use list comprehension with condition, to only look at even numbers
print "list comprehension with condition"
squares = [i*i for i in range(1,11) if i % 2 == 0]
print squares
print

print "list comprehension where each value is a list"
squares = [ [i, i*i] for i in range(1,10) if i % 2 == 0]
print squares
print

# print out element by element 
print " i, i^2"
print "-------"
for s in squares:
  print s

print

# use list comprehension to find the max value in each set of numbers
numbers = [ [1,3,5], [2,3,1], [3,7], [11,2,6] ]
m = [max(nums) for nums in numbers]
print "numbers = ", numbers
print "max of numbers is ", m
print 

# Question: use list comprehension to create a list where each element
# contains the minimum and maximum for each set of the above numbers


#######################################################
# Let's apply this concept to FASTA sequence data
#######################################################

from Bio import SeqIO # to parse sequence data

import urllib2  # to read file from url
from StringIO import StringIO # to convert string to 'handle'

# download 'file' from url 
url = "https://raw.githubusercontent.com/biopython/biopython/master/Doc/examples/ls_orchid.fasta"
openUrl = urllib2.urlopen(url)
seqString = openUrl.read() # convert contents to string

# when using SeqIO, we need a handle to an open file
# here, we convert the sequences string to a handle 
handle = StringIO(seqString) 

# parse the sequence data, returning an iterator
sequences = SeqIO.parse(handle, "fasta")

# convert the iterator to a list 
# (because python iterators cannot be reset)
sequences = [s for s in sequences]


##########################################################
# Answer some questions about the sequences
##########################################################

# Question: how many sequences are there?

# Question: use list comprehension to create a list containing the length
# of each sequence

# Question: use list comprehension to get the ID and length for each sequence that is
# less than 600 nucleotides long
