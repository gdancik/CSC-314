#########################################################################
# File Input, For more, see section 7.2 from:
#	https://docs.python.org/3.6/tutorial/inputoutput.html
#########################################################################

# set end = '' to keep output on a single line
print('a', end = '')   
print('b', end = '')
print()
print()
    
# store the file name in a string; you may need to specify the full path
file = "3-files.py"

# this will generate an error if the file cannot be opened
infile = open(file)

# print out each line of file; note that line ends with a '\n'
print ("The contents of the file are: ")
for line in infile :
  print (line, end = '')

# close the file
infile.close()


# additional useful file functions (assuming open file stored in object infile):
# infile.read() - reads entire file as a single string
# infile.readline() - reads the next line of the file, as a string
# infile.readlines() - reads the entire file into a list of strings, with each
#                      element a line of the file

# count the number of lines in a file
infile = open(file)
lines = infile.readlines()
infile.close()

print("second line is: ", lines[1])
print()
print("number of lines:", len(lines))


# An additional useful string function is strip, which removes
# whitespace characters (spaces, new lines, or tabs) from 
# the beginning or end of a string
# Note: strip does not change the string itself, but returns
# a copy with leading/trailing whitespace characters removed

x = "this is a line\n"
x.strip()




